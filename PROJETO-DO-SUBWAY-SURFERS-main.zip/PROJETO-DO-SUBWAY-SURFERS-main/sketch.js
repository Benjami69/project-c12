//é aqui que cria as variáveis


function preload(){
  //é aqui que carrega a imagem

  //é aqui que carrega a animação
 
}

function setup(){
  createCanvas(600,400)
  //é aqui que cria a sprite da estrada
  
  //é aqui que adiciona a imagem na sprite da estrada

  //é aqui que define a velocidade


  //é aqui que cria a sprite do jogador

  //é aqui que adiciona a animação do jogador na sprite

  //é aqui que define o tamanho

}

function draw(){
  background(0);

  //programar para a sprite de estrada estar em um loop infinito

    
  drawSprites();
}